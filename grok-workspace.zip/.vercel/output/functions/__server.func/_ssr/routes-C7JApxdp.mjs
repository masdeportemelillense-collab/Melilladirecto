import { i as __toESM } from "../_runtime.mjs";
import { r as SPORT_LABEL, s as teamPathSlug } from "./data-Ba0bI5RM.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as MapPin } from "../_libs/lucide-react.mjs";
import { i as getBoard, r as Route$1 } from "./router-DXBhfpsa.mjs";
import { a as cn, i as Standings, n as MatchCard, o as formatKickoffLong, r as SiteHeader, s as statusLabel, t as Crest } from "./standings-DUvgwovr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C7JApxdp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function parts(target, now) {
	const diff = Math.max(0, target - now);
	const total = Math.floor(diff / 1e3);
	return {
		days: Math.floor(total / 86400),
		hours: Math.floor(total % 86400 / 3600),
		minutes: Math.floor(total % 3600 / 60),
		seconds: total % 60,
		done: diff <= 0
	};
}
function Cell({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-14 flex-col items-center rounded-md bg-surface-2 px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-2xl leading-none tabular tracking-tight text-fg",
			children: String(value).padStart(2, "0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 text-xs uppercase tracking-wider text-subtle",
			children: label
		})]
	});
}
function Countdown({ iso }) {
	const target = new Date(iso).getTime();
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(Date.now());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	if (now == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-14",
		"aria-hidden": true
	});
	const t = parts(target, now);
	if (t.done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "El partido está a punto de empezar."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2",
		"aria-label": "Cuenta atrás",
		children: [
			t.days > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
				value: t.days,
				label: "días"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
				value: t.hours,
				label: "horas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
				value: t.minutes,
				label: "min"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
				value: t.seconds,
				label: "seg"
			})
		]
	});
}
function Side({ name, initials, crest, score, align }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: align === "left" ? "flex min-w-0 items-center gap-3" : "flex min-w-0 items-center gap-3 sm:flex-row-reverse",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
			initials,
			crest,
			size: "lg"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: align === "right" ? "min-w-0 sm:text-right" : "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate font-medium text-fg",
				children: name
			}), score != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-5xl leading-none tabular tracking-tight text-fg sm:text-6xl",
				children: score
			})]
		})]
	});
}
function HeroMatch({ match }) {
	const live = match.status === "live";
	const showScore = live || match.status === "ft";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "reveal min-w-0 overflow-hidden rounded-2xl bg-surface p-5 shadow-border sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex flex-wrap items-center justify-between gap-2 text-xs uppercase tracking-wider text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					SPORT_LABEL[match.sport],
					" · ",
					match.competition,
					match.round ? ` · ${match.round}` : ""
				] }), live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 font-medium text-live",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot size-1.5 rounded-full bg-live" }),
						"En directo · ",
						statusLabel(match)
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "capitalize",
					children: formatKickoffLong(match.kickoff)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-center gap-4 sm:grid-cols-[1fr_auto_1fr]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Side, {
						name: match.home.name,
						initials: match.home.initials,
						crest: match.home.crest,
						score: showScore ? match.score?.home : void 0,
						align: "left"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center",
						children: showScore ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-sm uppercase tracking-widest text-subtle",
							children: "vs"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl tabular text-muted",
							children: statusLabel(match)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Side, {
						name: match.away.name,
						initials: match.away.initials,
						crest: match.away.crest,
						score: showScore ? match.score?.away : void 0,
						align: "right"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "inline-flex items-center gap-1.5 text-sm text-subtle",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
						match.venue,
						" · ",
						match.city
					]
				}), match.status === "scheduled" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, { iso: match.kickoff })]
			})
		]
	});
}
var OPTIONS = [
	{
		id: "todos",
		label: "Todos"
	},
	{
		id: "futbol",
		label: SPORT_LABEL.futbol
	},
	{
		id: "futsal",
		label: SPORT_LABEL.futsal
	},
	{
		id: "baloncesto",
		label: SPORT_LABEL.baloncesto
	},
	{
		id: "voleibol",
		label: SPORT_LABEL.voleibol
	}
];
function SportFilter({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "w-full min-w-0 overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			role: "tablist",
			"aria-label": "Deporte",
			className: "flex w-max min-w-full gap-1 rounded-lg bg-surface p-1 shadow-border",
			children: OPTIONS.map((opt) => {
				const active = value === opt.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": active,
					onClick: () => onChange(opt.id),
					className: cn("h-11 shrink-0 rounded-md px-4 text-sm font-medium transition-colors duration-150", active ? "bg-fg text-bg" : "text-muted hover:text-fg"),
					children: opt.label
				}, opt.id);
			})
		})
	});
}
function TeamGrid({ teams }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: teams.map((team) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/equipo/$slug",
			params: { slug: team.slug },
			className: "flex items-center gap-3 rounded-xl bg-surface p-3 shadow-border transition-[box-shadow] duration-150 hover:shadow-border-hover",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
				initials: team.initials,
				crest: team.crest
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-medium text-fg",
					children: team.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-xs text-muted",
					children: [
						SPORT_LABEL[team.sport],
						team.gender === "F" ? " · Femenino" : "",
						" · ",
						team.league
					]
				})]
			})]
		}, team.id))
	});
}
function pick(list, sport, getSport) {
	if (sport === "todos") return list;
	return list.filter((item) => getSport(item) === sport);
}
function Home() {
	const initial = Route$1.useLoaderData();
	const { data } = useQuery({
		queryKey: ["board"],
		queryFn: () => getBoard(),
		initialData: initial,
		refetchInterval: 2e4
	});
	const [sport, setSport] = (0, import_react.useState)("todos");
	const live = (0, import_react.useMemo)(() => pick(data.live, sport, (m) => m.sport), [data.live, sport]);
	const upcoming = (0, import_react.useMemo)(() => pick(data.upcoming, sport, (m) => m.sport).slice(0, 8), [data.upcoming, sport]);
	const results = (0, import_react.useMemo)(() => pick(data.results, sport, (m) => m.sport).slice(0, 6), [data.results, sport]);
	const teams = (0, import_react.useMemo)(() => pick(data.teams, sport, (t) => t.sport), [data.teams, sport]);
	const hero = live[0] ?? (sport === "todos" ? data.next : upcoming[0] ?? live[0]);
	const heroSlug = hero ? teamPathSlug(hero.home.isMelilla ? hero.home.teamId : hero.away.teamId) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { liveCount: data.live.length }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full min-w-0 max-w-5xl flex-col gap-10 px-4 py-8 pb-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "reveal space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-accent",
								children: "Ciudad Autónoma de Melilla"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-4xl leading-none tracking-tight text-fg sm:text-5xl",
								children: "El deporte local, en un vistazo."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-xl text-sm leading-relaxed text-muted",
								children: "Resultados, próximos partidos y clasificación de los equipos melillenses en categoría nacional. Temporada 2026/27."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SportFilter, {
						value: sport,
						onChange: setSport
					}),
					hero && (heroSlug ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/equipo/$slug",
						params: { slug: heroSlug },
						className: "block min-w-0 rounded-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroMatch, { match: hero })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroMatch, { match: hero })),
					live.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Ahora",
							title: "En juego"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3",
							children: live.slice(1).map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
						})]
					}),
					upcoming.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Agenda",
							title: "Próximos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid min-w-0 gap-3 md:grid-cols-2",
							children: upcoming.filter((m) => m.id !== hero?.id).map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
						})]
					}),
					results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Cierre",
							title: "Últimos resultados"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid min-w-0 gap-3 md:grid-cols-2",
							children: results.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
						})]
					}),
					(sport === "todos" || sport === "futbol") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Liga",
							title: "Clasificación"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Standings, { rows: data.standings })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							kicker: "Ciudad",
							title: "Equipos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamGrid, { teams })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl flex-col gap-1 px-4 py-6 text-xs text-subtle sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Melilla Directo · Temporada 2026/27" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Horarios en hora peninsular · Actualización cada 20 s" })]
				})
			})
		]
	});
}
function SectionTitle({ kicker, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl tracking-tight text-fg",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs uppercase tracking-wider text-subtle",
			children: kicker
		})]
	});
}
//#endregion
export { Home as component };
