import { a as TEAMS, i as STANDINGS, n as MATCHES, t as DURATION_MS } from "./data-Ba0bI5RM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/board-CMzWXtpe.js
function footballMinute(elapsedMs) {
	const minutes = Math.floor(elapsedMs / 6e4);
	if (minutes < 45) return minutes;
	if (minutes < 60) return 45;
	const secondHalf = minutes - 15;
	return Math.min(secondHalf, 90);
}
function resolveMatch(match, now) {
	const start = new Date(match.kickoff).getTime();
	const end = start + DURATION_MS[match.sport];
	if (match.score && match.status === "ft") return {
		...match,
		status: "ft"
	};
	if (now >= start && now <= end && match.status !== "ft") {
		const elapsed = now - start;
		const minute = match.sport === "futbol" || match.sport === "futsal" ? footballMinute(elapsed) : Math.floor(elapsed / 6e4);
		return {
			...match,
			status: "live",
			minute,
			score: match.score ?? {
				home: 0,
				away: 0
			}
		};
	}
	if (now > end) return {
		...match,
		status: "ft",
		score: match.score ?? {
			home: 0,
			away: 0
		}
	};
	return {
		...match,
		status: "scheduled",
		minute: void 0
	};
}
function namesMatch(a, b) {
	const n = (s) => s.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");
	return n(a).includes(n(b)) || n(b).includes(n(a));
}
function mergeRemote(local, remote) {
	return local.map((match) => {
		const hit = remote.find((r) => namesMatch(r.home.name, match.home.name) && namesMatch(r.away.name, match.away.name));
		if (!hit) return match;
		return {
			...match,
			kickoff: hit.kickoff || match.kickoff,
			score: hit.score ?? match.score,
			status: hit.status === "ft" || hit.score ? hit.status : match.status
		};
	});
}
function buildBoard(now = Date.now(), overlay = []) {
	const matches = mergeRemote(MATCHES, overlay).map((m) => resolveMatch(m, now)).sort((a, b) => new Date(a.kickoff).getTime() - new Date(b.kickoff).getTime());
	const live = matches.filter((m) => m.status === "live");
	const upcoming = matches.filter((m) => m.status === "scheduled");
	const results = matches.filter((m) => m.status === "ft").sort((a, b) => new Date(b.kickoff).getTime() - new Date(a.kickoff).getTime());
	return {
		generatedAt: new Date(now).toISOString(),
		timezone: "Europe/Madrid",
		live,
		upcoming,
		results,
		matches,
		teams: TEAMS,
		standings: STANDINGS,
		next: live[0] ?? upcoming[0] ?? null
	};
}
function matchesForTeam(board, teamId) {
	return board.matches.filter((m) => m.home.teamId === teamId || m.away.teamId === teamId);
}
//#endregion
export { matchesForTeam as n, buildBoard as t };
