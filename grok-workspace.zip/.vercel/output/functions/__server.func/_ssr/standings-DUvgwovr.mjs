import { i as __toESM } from "../_runtime.mjs";
import { r as SPORT_LABEL, s as teamPathSlug } from "./data-Ba0bI5RM.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Radio, r as MapPin } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/standings-DUvgwovr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var CREST = {
	navy: "bg-surface-2 text-accent",
	steel: "bg-accent text-accent-fg",
	ink: "bg-fg text-bg",
	wave: "bg-surface text-accent",
	mist: "bg-surface-2 text-fg",
	slate: "bg-surface text-muted",
	stone: "bg-surface-2 text-muted",
	away: "bg-surface-2 text-subtle"
};
function Crest({ initials, crest, size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex shrink-0 items-center justify-center rounded-md font-display font-medium tracking-wide", CREST[crest] ?? CREST.away, size === "sm" && "size-8 text-xs", size === "md" && "size-10 text-sm", size === "lg" && "size-14 text-base"),
		"aria-hidden": true,
		children: initials.slice(0, 3)
	});
}
var TZ = "Europe/Madrid";
function fmt(iso, options) {
	return new Intl.DateTimeFormat("es-ES", {
		timeZone: TZ,
		hour12: false,
		...options
	}).format(new Date(iso));
}
function ymdInMadrid(date) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: TZ,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(date);
}
function nextYmd(ymd) {
	const [year, month, day] = ymd.split("-").map(Number);
	const next = new Date(Date.UTC(year, month - 1, day + 1));
	return `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}-${String(next.getUTCDate()).padStart(2, "0")}`;
}
function formatKickoffLong(iso) {
	return fmt(iso, {
		weekday: "long",
		day: "numeric",
		month: "long",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function formatClock(iso) {
	return fmt(iso, {
		hour: "2-digit",
		minute: "2-digit"
	});
}
function formatDay(iso) {
	const target = ymdInMadrid(new Date(iso));
	const today = ymdInMadrid(/* @__PURE__ */ new Date());
	if (target === today) return "Hoy";
	if (target === nextYmd(today)) return "Mañana";
	return fmt(iso, {
		weekday: "short",
		day: "numeric",
		month: "short"
	});
}
function statusLabel(match) {
	if (match.status === "live") {
		if (match.minute != null && (match.sport === "futbol" || match.sport === "futsal")) return `${match.minute}'`;
		return "En juego";
	}
	if (match.status === "ft") return "Final";
	return formatClock(match.kickoff);
}
function resultForMelilla(match) {
	if (match.status !== "ft" || !match.score) return null;
	const us = match.home.isMelilla ? match.score.home : match.score.away;
	const them = match.home.isMelilla ? match.score.away : match.score.home;
	if (us > them) return "W";
	if (us < them) return "L";
	return "D";
}
function TeamRow({ name, initials, crest, score, dim }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-3", dim && "opacity-55"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
				initials,
				crest,
				size: "sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 truncate font-medium text-fg",
				children: name
			}),
			score != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-2xl leading-none tabular tracking-tight text-fg",
				children: score
			})
		]
	});
}
function MatchCard({ match, featured = false }) {
	const live = match.status === "live";
	const ft = match.status === "ft";
	const showScore = live || ft;
	const result = resultForMelilla(match);
	const homeDim = ft && match.score && match.score.home < match.score.away;
	const awayDim = ft && match.score && match.score.away < match.score.home;
	const slug = match.home.isMelilla ? teamPathSlug(match.home.teamId) : match.away.isMelilla ? teamPathSlug(match.away.teamId) : void 0;
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("min-w-0 w-full overflow-hidden rounded-xl bg-surface p-4 shadow-border transition-[box-shadow,transform] duration-150 ease-out", featured && "rounded-2xl p-5", live && "shadow-border-hover", slug && "hover:shadow-border-hover"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-3 flex items-center justify-between gap-3 text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 truncate",
					children: [
						SPORT_LABEL[match.sport],
						" · ",
						match.competition,
						match.round ? ` · ${match.round}` : ""
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex shrink-0 items-center gap-2",
					children: [
						live && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 font-medium uppercase tracking-wider text-live",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot size-1.5 rounded-full bg-live" }), "En directo"]
						}),
						ft && result && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-xs px-1.5 py-0.5 font-medium uppercase tracking-wide", result === "W" && "bg-win/15 text-win", result === "L" && "bg-live/15 text-live", result === "D" && "bg-surface-2 text-muted"),
							children: result === "W" ? "Victoria" : result === "L" ? "Derrota" : "Empate"
						}),
						match.status === "scheduled" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "capitalize",
							children: formatDay(match.kickoff)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamRow, {
					name: match.home.name,
					initials: match.home.initials,
					crest: match.home.crest,
					score: showScore ? match.score?.home : void 0,
					dim: homeDim
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamRow, {
					name: match.away.name,
					initials: match.away.initials,
					crest: match.away.crest,
					score: showScore ? match.score?.away : void 0,
					dim: awayDim
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-3 flex items-center justify-between gap-3 text-xs text-subtle",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex min-w-0 items-center gap-1.5 truncate",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "truncate",
						children: [match.venue, match.city ? ` · ${match.city}` : ""]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-lg leading-none tabular tracking-tight text-fg",
					children: statusLabel(match)
				})]
			})
		]
	});
	if (!slug) return inner;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/equipo/$slug",
		params: { slug },
		className: "block min-w-0 w-full rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60",
		children: inner
	});
}
function MadridClock() {
	const [label, setLabel] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const tick = () => {
			setLabel((/* @__PURE__ */ new Date()).toLocaleTimeString("es-ES", {
				timeZone: "Europe/Madrid",
				hour: "2-digit",
				minute: "2-digit"
			}));
		};
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	if (!label) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
		className: "font-display text-lg tabular tracking-tight text-fg",
		dateTime: label,
		children: label
	});
}
function SiteHeader({ liveCount }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-20 border-b border-border bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-5xl items-center justify-between gap-4 px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-baseline gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl tracking-tight text-fg",
					children: "Melilla"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl tracking-tight text-accent",
					children: "Directo"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [liveCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-live",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3.5" }),
						liveCount,
						" en juego"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden text-right sm:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-subtle",
						children: "Melilla"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MadridClock, {})]
				})]
			})]
		})
	});
}
function Standings({ rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl bg-surface shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg tracking-tight text-fg",
				children: "Tercera Federación"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs uppercase tracking-wider text-subtle",
				children: "Grupo 9"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-80 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-xs uppercase tracking-wider text-subtle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-medium",
								children: "#"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-medium",
								children: "Equipo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2 text-right font-medium",
								children: "PJ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2 text-right font-medium",
								children: "G"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "hidden px-2 py-2 text-right font-medium sm:table-cell",
								children: "E"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "hidden px-2 py-2 text-right font-medium sm:table-cell",
								children: "P"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2 text-right font-medium",
								children: "DG"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right font-medium",
								children: "Pts"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: cn("border-t border-border", row.isMelilla && "bg-accent/10 text-fg"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5 tabular text-muted",
							children: row.pos
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5 font-medium",
							children: row.short
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2.5 text-right tabular text-muted",
							children: row.played
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2.5 text-right tabular text-muted",
							children: row.won
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "hidden px-2 py-2.5 text-right tabular text-muted sm:table-cell",
							children: row.drawn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "hidden px-2 py-2.5 text-right tabular text-muted sm:table-cell",
							children: row.lost
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2.5 text-right tabular text-muted",
							children: row.gf - row.ga > 0 ? `+${row.gf - row.ga}` : row.gf - row.ga
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2.5 text-right font-display text-base tabular",
							children: row.pts
						})
					]
				}, row.teamId)) })]
			})
		})]
	});
}
//#endregion
export { cn as a, Standings as i, MatchCard as n, formatKickoffLong as o, SiteHeader as r, statusLabel as s, Crest as t };
