import { t as buildBoard } from "./board-CMzWXtpe.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/get-board-DWK1XhW-.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getBoard_createServerFn_handler = createServerRpc({
	id: "f814f5b6b9ab0adfa74fbdd0101e3b5e7da23d63a32c42954d2d3e8db1c3aee4",
	name: "getBoard",
	filename: "src/lib/sports/get-board.ts"
}, (opts) => getBoard.__executeServer(opts));
var getBoard = createServerFn({ method: "GET" }).handler(getBoard_createServerFn_handler, async () => {
	const { fetchRemoteMatches } = await import("./remote-FlU1DE-4.mjs");
	const overlay = await fetchRemoteMatches();
	return buildBoard(Date.now(), overlay);
});
//#endregion
export { getBoard_createServerFn_handler };
