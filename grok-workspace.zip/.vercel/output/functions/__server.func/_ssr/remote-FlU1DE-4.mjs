//#region node_modules/.nitro/vite/services/ssr/assets/remote-FlU1DE-4.js
function toIso(date, time) {
	if (!date) return "";
	return `${date}T${(time || "00:00:00").length === 5 ? `${time}:00` : time || "00:00:00"}Z`;
}
function mapEvent(ev) {
	if (!ev.strHomeTeam || !ev.strAwayTeam) return null;
	const homeScore = ev.intHomeScore == null ? void 0 : Number(ev.intHomeScore);
	const awayScore = ev.intAwayScore == null ? void 0 : Number(ev.intAwayScore);
	const hasScore = Number.isFinite(homeScore) && Number.isFinite(awayScore);
	const statusRaw = (ev.strStatus || ev.strProgress || "").toLowerCase();
	const live = statusRaw.includes("live") || statusRaw.includes("1h") || statusRaw.includes("2h") || statusRaw.includes("ht");
	const ft = statusRaw === "ft" || statusRaw.includes("match finished") || hasScore && !live;
	return {
		id: `remote-${ev.dateEvent}-${ev.strHomeTeam}`,
		sport: "futbol",
		competition: ev.strLeague || "Fútbol",
		kickoff: toIso(ev.dateEvent, ev.strTime),
		venue: "",
		city: "",
		home: {
			teamId: "",
			name: ev.strHomeTeam,
			short: ev.strHomeTeam,
			initials: ev.strHomeTeam.slice(0, 3).toUpperCase(),
			crest: "away",
			isMelilla: /melilla/i.test(ev.strHomeTeam)
		},
		away: {
			teamId: "",
			name: ev.strAwayTeam,
			short: ev.strAwayTeam,
			initials: ev.strAwayTeam.slice(0, 3).toUpperCase(),
			crest: "away",
			isMelilla: /melilla/i.test(ev.strAwayTeam)
		},
		score: hasScore ? {
			home: homeScore,
			away: awayScore
		} : void 0,
		status: live ? "live" : ft ? "ft" : "scheduled"
	};
}
async function fetchJson(url) {
	const res = await fetch(url, {
		headers: { "User-Agent": "MelillaDirecto/1.0" },
		signal: AbortSignal.timeout(4e3)
	});
	if (!res.ok) return null;
	return await res.json();
}
async function fetchRemoteMatches() {
	try {
		const [last, next] = await Promise.all([fetchJson("https://www.thesportsdb.com/api/v1/json/123/eventslast.php?id=137847"), fetchJson("https://www.thesportsdb.com/api/v1/json/123/eventsnext.php?id=137847")]);
		return [...last?.results ?? last?.events ?? [], ...next?.events ?? []].map(mapEvent).filter((m) => m != null);
	} catch {
		return [];
	}
}
//#endregion
export { fetchRemoteMatches };
