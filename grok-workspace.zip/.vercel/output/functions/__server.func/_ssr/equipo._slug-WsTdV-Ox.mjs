import { o as teamBySlug, r as SPORT_LABEL } from "./data-Ba0bI5RM.mjs";
import { n as matchesForTeam } from "./board-CMzWXtpe.mjs";
import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ArrowLeft, r as MapPin } from "../_libs/lucide-react.mjs";
import { i as getBoard, n as Route } from "./router-DXBhfpsa.mjs";
import { i as Standings, n as MatchCard, r as SiteHeader, t as Crest } from "./standings-DUvgwovr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/equipo._slug-WsTdV-Ox.js
var import_jsx_runtime = require_jsx_runtime();
function TeamPage() {
	const { slug } = Route.useParams();
	const initial = Route.useLoaderData();
	const { data } = useQuery({
		queryKey: ["board"],
		queryFn: () => getBoard(),
		initialData: initial,
		refetchInterval: 2e4
	});
	const team = teamBySlug(slug);
	if (!team) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { liveCount: data.live.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-5xl px-4 py-16 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Equipo no encontrado"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-4 inline-block text-sm text-accent",
				children: "Volver al marcador"
			})]
		})]
	});
	const teamMatches = matchesForTeam(data, team.id);
	const live = teamMatches.filter((m) => m.status === "live");
	const upcoming = teamMatches.filter((m) => m.status === "scheduled");
	const results = teamMatches.filter((m) => m.status === "ft").sort((a, b) => new Date(b.kickoff).getTime() - new Date(a.kickoff).getTime());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { liveCount: data.live.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex w-full min-w-0 max-w-5xl flex-col gap-8 px-4 py-8 pb-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex h-11 w-fit items-center gap-2 text-sm text-muted hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Marcador"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex items-start gap-4 rounded-2xl bg-surface p-5 shadow-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						initials: team.initials,
						crest: team.crest,
						size: "lg"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs uppercase tracking-wider text-accent",
								children: [SPORT_LABEL[team.sport], team.gender === "F" ? " · Femenino" : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 font-display text-3xl leading-none tracking-tight text-fg sm:text-4xl",
								children: team.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: team.league
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 inline-flex items-center gap-1.5 text-sm text-subtle",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), team.venue]
							})
						]
					})]
				}),
				live.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "En juego"
					}), live.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
						match,
						featured: true
					}, match.id))]
				}),
				upcoming.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Próximos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid min-w-0 gap-3 md:grid-cols-2",
						children: upcoming.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
					})]
				}),
				results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Resultados"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid min-w-0 gap-3 md:grid-cols-2",
						children: results.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
					})]
				}),
				upcoming.length === 0 && results.length === 0 && live.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-xl bg-surface p-5 text-sm text-muted shadow-border",
					children: [
						"La liga arranca en octubre. El calendario de ",
						team.name,
						" se publicará aquí en cuanto se confirme."
					]
				}),
				team.id === "ud-melilla" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Standings, { rows: data.standings })
			]
		})]
	});
}
//#endregion
export { TeamPage as component };
