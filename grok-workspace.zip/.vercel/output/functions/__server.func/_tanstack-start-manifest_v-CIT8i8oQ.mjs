//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CIT8i8oQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/equipo/$slug"],
		preloads: ["/assets/index-Drl11tnu.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Drl11tnu.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BqT1apzL.js", "/assets/standings-B3IS5XCb.js"]
	},
	"/equipo/$slug": {
		filePath: "/workspace/src/routes/equipo.$slug.tsx",
		children: void 0,
		preloads: ["/assets/equipo._slug-CchaT3zd.js", "/assets/standings-B3IS5XCb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
