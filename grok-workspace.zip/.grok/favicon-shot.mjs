import { chromium } from "playwright";
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 220, height: 100 } });
await page.setContent(`<!doctype html><html><body style="margin:0;background:#5a6570;display:flex;gap:16px;padding:16px;align-items:flex-end">
  <img src="file:///workspace/public/favicon.svg" width="16" height="16">
  <img src="file:///workspace/public/favicon.svg" width="32" height="32">
  <img src="file:///workspace/public/favicon.svg" width="64" height="64">
</body></html>`);
await page.screenshot({ path: "/workspace/.grok/favicon-sizes.png" });
await page.setViewportSize({ width: 16, height: 16 });
await page.setContent(`<!doctype html><html><body style="margin:0;background:#5a6570">
  <img src="file:///workspace/public/favicon.svg" width="16" height="16">
</body></html>`);
await page.screenshot({ path: "/workspace/.grok/favicon-16.png" });
await browser.close();
console.log("ok");
